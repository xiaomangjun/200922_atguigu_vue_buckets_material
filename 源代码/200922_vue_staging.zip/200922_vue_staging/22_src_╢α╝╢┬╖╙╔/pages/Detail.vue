<template>
	<ul>
		<li>ID：？？？？</li>
		<li>TITLE：？？？？</li>
		<li>CONTENT：？？？？</li>
	</ul>
</template>

<script>
	export default {
		name:'Detail'
	}
</script>
