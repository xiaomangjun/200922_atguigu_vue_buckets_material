<template>
	<h2>我是Home2的内容</h2>
</template>

<script>
	export default {
		name:'Home2'
	}
</script>
