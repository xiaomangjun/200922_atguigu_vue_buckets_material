<template>
	<h2 class="demo">你好我是Welcome组件</h2>
</template>


<style scoped>
	.demo{
		background-color: red;
	}
</style>