<template>
	<div>
		<el-button>默认按钮</el-button>
		<el-button type="primary">主要按钮</el-button>
		<el-button type="success">成功按钮</el-button>
		<el-button type="info">信息按钮</el-button>
		<el-button type="warning">警告按钮</el-button>
		<el-button type="danger">危险按钮</el-button>
		<el-input placeholder="请输入内容"></el-input>
	</div>
</template>

<script>
	// import {el-button,el-input} from 'element-ui'
	export default {
		name:'App',
		// components:{el-button,el-input}
	}
</script>