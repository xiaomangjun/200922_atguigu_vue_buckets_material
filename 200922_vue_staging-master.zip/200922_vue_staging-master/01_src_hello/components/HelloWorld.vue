<template>
	<h2 class="title">Hello,{{name}}</h2>
</template>

<script>
	export default {
		data(){
			return {
				name:"尚硅谷"
			}
		}
	}
</script>

<style>
	.title{
		background-color: orange;
	}
</style>